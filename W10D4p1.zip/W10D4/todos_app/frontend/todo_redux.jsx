import React from 'react';
import ReactDOM from 'react-dom';
import store from './store/store.js';
import { receiveTodos, receiveTodo} from './actions/todo_actions'


window.store = store;
window.receiveTodos = receiveTodos;
window.receiveTodo = receiveTodo;

document.addEventListener('DOMContentLoaded', () => {
  const main = document.getElementById('main')
  const todos = <h1>Todos App</h1>;

    ReactDOM.render(todos, main)
});

// function Todos(props){
//     return <h1>TODO's APP</h1>;
// };