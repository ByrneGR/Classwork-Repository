import { merge } from 'lodash';
import { RECEIVE_TODOS, RECEIVE_TODO } from '../actions/todo_actions.js';

const initialState = {
  1: {
    id: 1,
    title: "wash car",
    body: "with soap",
    done: false
  },
  2: {
    id: 2,
    title: "wash dog",
    body: "with shampoo",
    done: true
  }
};


const todosReducer = (state= initialState, action)=>{
    Object.freeze(state);

    switch(action.type){ // switch starts up if action.type is truthy (which itll always be)
        case RECEIVE_TODOS:
            const { todos } = action // convert this array into an object where the keys are the id's of the individual todos and the values are the todos
                                    //const returnedTarget = Object.assign(target, source);
            const newObject = Object.assign({}, todos);
            return newObject;
        case RECEIVE_TODO:
            const { id, title, body, done } = action
            const newTodo = {
                [id]:{
                    id,
                    title,
                    body,
                    done
                }
            };
            const newState = Object.assign({}, newTodo, state);
            return newState;


        default: return state;
    }
    
};

export default todosReducer;