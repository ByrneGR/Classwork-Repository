import React from 'react';


const App = () => (
    <div>
        <h1>Bench BnB</h1>
    </div>
);

export default App;