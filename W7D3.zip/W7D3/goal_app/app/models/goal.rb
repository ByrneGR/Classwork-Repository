class Goal < ApplicationRecord

end