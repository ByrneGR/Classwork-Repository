module Api::PokemonControllerHelper
end
