require 'test_helper'

class Api::PokemonControllerControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
