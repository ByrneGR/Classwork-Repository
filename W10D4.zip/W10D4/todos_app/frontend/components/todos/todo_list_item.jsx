import React from 'react';

class TodoListItem extends React.Component {
    constructor(props) {
      super(props)
    }

    render() {
    //   debugger;
      return (<li>{this.props.todos.title}</li>)
    }
}

export default TodoListItem