import React from 'react';
import ToDoListItem from './todo_list_item.jsx';

class TodoList extends React.Component {
  constructor(props) {
    super(props);
  }
  render(){
    // debugger;
    
      const listOfToDos = this.props.todos.map((todo, idx) => {
        return (<li key={idx}>{todo.title}</li>)
      })
    

      return(
        // debugger;
        // console.log(this.props.todos)
        <ul>
        {listOfToDos}
        </ul>
        // <ul>
        // <ToDoListItem />
        // </ul>
      
      );
  }
}
// const TodoList = () => (
//     <h3>Todo List goes here!</h3>
//     <ul>
//       console.log(props.todos)
//     </ul>
//   );
export default TodoList;