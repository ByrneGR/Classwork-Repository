const itemsReducer = (state = {}, action) => {
    Object.freeze(state);

    // switch(action.type) {

    // }
}

export default itemsReducer;